import React, { createContext, useContext, useState, useEffect } from 'react';
import type { AuthState } from '../types/auth.types';
import { authService } from '../services/auth/authService';
import * as CustomerService from '../services/customer/customerService';

interface AuthContextType extends AuthState {
  login: (user: any) => void;
  logout: () => void;
  isCustomer: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    token: null, // Left for legacy types support, but completely unused
    isAuthenticated: false,
    isLoading: true,
  });
  const [isCustomer, setIsCustomer] = useState(false);

  useEffect(() => {
    // On page load, ask the Spring Boot server if our JSESSIONID cookie is still valid
    const verifySession = async () => {
      try {
        console.log('Checking session...');
        const user = await authService.checkSession();
        console.log('Session check success:', user);
        if (user && user.email) {
          setAuthState({
            user,
            token: null,
            isAuthenticated: true,
            isLoading: false,
          });
          // Store auth flag for cross-tab sync
          sessionStorage.setItem('isAuthenticated', 'true');
          // Check if user is a customer
          try {
            const customerStatus = await CustomerService.getCustomerStatus();
            setIsCustomer(customerStatus.isCustomer);
            sessionStorage.setItem('isCustomer', String(customerStatus.isCustomer));
          } catch {
            // If customer status check fails, assume not a customer
            setIsCustomer(false);
            sessionStorage.setItem('isCustomer', 'false');
          }
        } else {
          console.log('No user in session response');
          setAuthState(prev => ({ ...prev, isLoading: false }));
          setIsCustomer(false);
          sessionStorage.removeItem('isAuthenticated');
          sessionStorage.removeItem('isCustomer');
        }
      } catch (err: any) {
        // 401 is expected when not logged in - don't log as error
        if (err.message?.includes('401') || err.message?.includes('Unauthorized')) {
          console.log('Session: Not authenticated (401 expected)');
        } else {
          console.error('Session check error:', err.message || err);
        }
        setAuthState(prev => ({ ...prev, isLoading: false }));
        setIsCustomer(false);
        sessionStorage.removeItem('isAuthenticated');
        sessionStorage.removeItem('isCustomer');
      }
    };

    // Always verify session on page load, regardless of current page
    // This ensures consistent auth state across reloads and tabs
    verifySession();
  }, []);

  // Listen for storage changes (cross-tab sync)
  useEffect(() => {
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === 'isAuthenticated') {
        // Another tab logged in or out, reload to sync state
        window.location.reload();
      }
    };
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const login = (user: any) => {
    console.log('Login called with user:', user);
    // Ensure role is properly set (backend sends 'ADMIN', we need 'ADMIN')
    if (user && user.role) {
      console.log('User role from backend:', user.role);
    }
    setAuthState({
      user,
      token: null,
      isAuthenticated: true,
      isLoading: false,
    });
    // Set sessionStorage for cross-tab sync
    sessionStorage.setItem('isAuthenticated', 'true');
  };

  const logout = async () => {
    console.log('Logout called, redirecting to /');
    try {
      // Try to call backend logout, but don't fail if session already expired
      await authService.logout();
      console.log('Backend logout successful');
    } catch (e: any) {
      // 401 means session was already invalid - that's fine, we still want to logout client-side
      console.log('Logout API call completed (may have been 401):', e.message);
    }
    // Clear sessionStorage flags
    sessionStorage.removeItem('isAuthenticated');
    sessionStorage.removeItem('isCustomer');
    // Immediate hard redirect - page reload will reset auth state naturally
    window.location.href = '/';
  };

  return (
    <AuthContext.Provider value={{ ...authState, login, logout, isCustomer }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuthContext = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuthContext must be used within an AuthProvider');
  }
  return context;
};
