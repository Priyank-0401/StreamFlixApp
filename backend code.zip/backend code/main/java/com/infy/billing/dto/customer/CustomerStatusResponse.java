package com.infy.billing.dto.customer;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerStatusResponse {
    private boolean isCustomer;
    private boolean hasActiveSubscription;
    private String message;
}
